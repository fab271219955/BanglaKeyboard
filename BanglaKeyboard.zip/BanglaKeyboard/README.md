# Bangla Keyboard (Android IME)
Build: push to GitHub -> Actions -> "Build APK" -> download artifact BanglaKeyboard-APK (app-debug.apk).
Or Android Studio: open folder, Run.
After install: open app -> (1) enable keyboard -> (2) choose keyboard.
Phonetic tips: ami=আমি, bangla=বাংলা, capital O = ো (bhalO), valo=ভালো, ch=ছ, c=চ, T/Th/D/Dh = ট/ঠ/ড/ঢ, ng=ং, Ng=ঙ, t``=ৎ.

Update without uninstalling: app/debug.keystore is a fixed signing key. Keep this file in the repo - every build is signed with it, so a new APK installs over the old one. (Only the very first install after switching to this key needs one uninstall.) versionCode = GitHub run number (goes up each build).

Number pad: tap ?১২৩ / ?123 -> number pad (digits, + * / % , ? = . , space, backspace, round check). Small hint on keys = long-press (e.g. + -> -, bn digit ১২৩). Long-press ?১২৩ for the old full symbol page.
Voice typing: mic is amber while starting, green (+ tick) when it is really listening. Android 13+ uses one continuous session (no restart gap); the speech service is pre-warmed when the keyboard opens.
