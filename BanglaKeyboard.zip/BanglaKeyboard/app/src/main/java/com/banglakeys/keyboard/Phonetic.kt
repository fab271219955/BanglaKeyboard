package com.banglakeys.keyboard

/** Avro-style phonetic converter (compact). Capital letters: T Th D Dh N Sh R Rh O Ng NG. */
object Phonetic {
    private val cons = mapOf(
        "kkh" to "ক্ষ", "kh" to "খ", "gh" to "ঘ", "Ng" to "ঙ", "chh" to "ছ", "ch" to "ছ", "jh" to "ঝ",
        "NG" to "ঞ", "Th" to "ঠ", "Dh" to "ঢ", "th" to "থ", "dh" to "ধ", "ph" to "ফ", "bh" to "ভ",
        "sh" to "শ", "Sh" to "ষ", "Rh" to "\u09DD", "k" to "ক", "g" to "গ", "c" to "চ", "j" to "জ",
        "T" to "ট", "D" to "ড", "N" to "ণ", "t" to "ত", "d" to "দ", "n" to "ন", "p" to "প", "f" to "ফ",
        "b" to "ব", "v" to "ভ", "m" to "ম", "z" to "য", "r" to "র", "l" to "ল", "s" to "স", "h" to "হ",
        "R" to "\u09DC", "y" to "\u09DF", "x" to "ক্স", "q" to "ক"
    )
    private val vow = mapOf(
        "rri" to Pair("ঋ", "\u09C3"), "oi" to Pair("ঐ", "\u09C8"), "ou" to Pair("ঔ", "\u09CC"),
        "ee" to Pair("ঈ", "\u09C0"), "oo" to Pair("ঊ", "\u09C2"), "a" to Pair("আ", "\u09BE"),
        "i" to Pair("ই", "\u09BF"), "I" to Pair("ঈ", "\u09C0"), "u" to Pair("উ", "\u09C1"),
        "U" to Pair("ঊ", "\u09C2"), "e" to Pair("এ", "\u09C7"), "O" to Pair("ও", "\u09CB"),
        "w" to Pair("ও", "\u09CB")
    )
    private val sign = mapOf(
        "t``" to "ৎ", "ng" to "ং", ":" to "ঃ", "^" to "ঁ", "$" to "৳",
        "0" to "০", "1" to "১", "2" to "২", "3" to "৩", "4" to "৪",
        "5" to "৫", "6" to "৬", "7" to "৭", "8" to "৮", "9" to "৯"
    )

    fun convert(s: String): String {
        val sb = StringBuilder()
        var prev = false // previous token was a consonant (no kar yet)
        var i = 0
        while (i < s.length) {
            var done = false
            for (len in minOf(3, s.length - i) downTo 1) {
                val t = s.substring(i, i + len)
                val c = cons[t]
                if (c != null) {
                    if (prev) sb.append('\u09CD')
                    sb.append(c); prev = true; i += len; done = true; break
                }
                val v = vow[t]
                if (v != null) {
                    sb.append(if (prev) v.second else v.first); prev = false; i += len; done = true; break
                }
                if (t == "o") {
                    if (!prev) sb.append('\u0985')
                    else if (i + 1 == s.length && sb.length >= 2 && sb[sb.length - 2] == '\u09BE') sb.append('\u09CB') // valo -> ভালো
                    prev = false; i += 1; done = true; break
                }
                val g = sign[t]
                if (g != null) { sb.append(g); prev = false; i += len; done = true; break }
            }
            if (!done) { sb.append(s[i]); prev = false; i++ }
        }
        return sb.toString()
    }
}
