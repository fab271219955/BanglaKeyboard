package com.banglakeys.keyboard

import android.content.Context
import android.content.SharedPreferences
import android.os.Handler
import android.os.Looper
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Manages the int8 quantized Bengali streaming model
 * (vosk-small-streaming-bn-int8 ≈ 29 MB).
 *
 * Files are stored under: filesDir/vosk-bn-int8/
 *   - encoder.int8.onnx
 *   - decoder.onnx
 *   - joiner.int8.onnx
 *   - tokens.txt
 */
object OfflineModelManager {

    private const val PREF_READY = "offline_model_ready"
    private const val PREF_SIZE  = "offline_model_bytes"
    private const val DIR_NAME  = "vosk-bn-int8"

    // Hugging Face raw URLs for the int8 quantized model
    private val FILES = listOf(
        "encoder.int8.onnx" to "https://huggingface.co/bbbipul/vosk-small-streaming-bn-int8/resolve/main/encoder.int8.onnx",
        "decoder.onnx"      to "https://huggingface.co/bbbipul/vosk-small-streaming-bn-int8/resolve/main/decoder.onnx",
        "joiner.int8.onnx"  to "https://huggingface.co/bbbipul/vosk-small-streaming-bn-int8/resolve/main/joiner.int8.onnx",
        "tokens.txt"        to "https://huggingface.co/bbbipul/vosk-small-streaming-bn-int8/resolve/main/tokens.txt"
    )

    private val executor = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private val downloading = AtomicBoolean(false)

    data class Status(
        val ready: Boolean,
        val downloading: Boolean,
        val progress: Int,          // 0–100
        val message: String,
        val sizeMb: Float = 0f
    )

    interface Listener {
        fun onProgress(status: Status)
        fun onFinished(success: Boolean, message: String)
    }

    fun modelDir(ctx: Context): File = File(ctx.filesDir, DIR_NAME)

    fun isReady(ctx: Context): Boolean {
        val dir = modelDir(ctx)
        if (!dir.isDirectory) return false
        return FILES.all { File(dir, it.first).exists() && File(dir, it.first).length() > 100 }
    }

    fun currentStatus(ctx: Context, prefs: SharedPreferences): Status {
        val ready = isReady(ctx)
        val bytes = prefs.getLong(PREF_SIZE, 0L)
        val mb = if (bytes > 0) bytes / (1024f * 1024f) else 0f
        return when {
            downloading.get() -> Status(false, true, 0, "ডাউনলোড চলছে…", mb)
            ready             -> Status(true, false, 100, "মডেল প্রস্তুত (≈ ${"%.0f".format(mb.coerceAtLeast(29f))} MB)", mb.coerceAtLeast(29f))
            else              -> Status(false, false, 0, "মডেল নেই — ডাউনলোড করুন (≈ ২৯ MB)", 0f)
        }
    }

    fun deleteModel(ctx: Context, prefs: SharedPreferences) {
        modelDir(ctx).deleteRecursively()
        prefs.edit().remove(PREF_READY).remove(PREF_SIZE).apply()
    }

    /**
     * Starts download on background thread.
     * Safe to call multiple times — only one download runs.
     */
    fun download(ctx: Context, prefs: SharedPreferences, listener: Listener?) {
        if (!downloading.compareAndSet(false, true)) {
            listener?.onFinished(false, "ইতিমধ্যে ডাউনলোড চলছে")
            return
        }

        executor.execute {
            val dir = modelDir(ctx)
            dir.mkdirs()
            var totalBytes = 0L
            var success = true
            var errorMsg = ""

            try {
                val totalFiles = FILES.size
                FILES.forEachIndexed { index, (name, urlStr) ->
                    val outFile = File(dir, name)
                    if (outFile.exists() && outFile.length() > 100) {
                        totalBytes += outFile.length()
                        val pct = ((index + 1) * 100) / totalFiles
                        main.post {
                            listener?.onProgress(Status(false, true, pct, "আছে: $name", totalBytes / (1024f * 1024f)))
                        }
                        return@forEachIndexed
                    }

                    main.post {
                        listener?.onProgress(Status(false, true, (index * 100) / totalFiles, "ডাউনলোড: $name …", 0f))
                    }

                    val url = URL(urlStr)
                    val conn = url.openConnection() as HttpURLConnection
                    conn.connectTimeout = 30_000
                    conn.readTimeout = 60_000
                    conn.instanceFollowRedirects = true
                    conn.setRequestProperty("User-Agent", "BanglaKeyboard/1.0")
                    conn.connect()

                    if (conn.responseCode !in 200..299) {
                        throw Exception("HTTP ${conn.responseCode} for $name")
                    }

                    val length = conn.contentLengthLong.coerceAtLeast(0)
                    conn.inputStream.use { input ->
                        FileOutputStream(outFile).use { output ->
                            val buf = ByteArray(64 * 1024)
                            var read: Int
                            var written = 0L
                            while (input.read(buf).also { read = it } != -1) {
                                output.write(buf, 0, read)
                                written += read
                                if (length > 0 && written % (256 * 1024) < buf.size) {
                                    val filePct = (written * 100 / length).toInt().coerceIn(0, 100)
                                    val overall = (index * 100 + filePct) / totalFiles
                                    main.post {
                                        listener?.onProgress(
                                            Status(false, true, overall, "$name  $filePct%", written / (1024f * 1024f))
                                        )
                                    }
                                }
                            }
                            totalBytes += written
                        }
                    }
                    conn.disconnect()
                }

                // final check
                if (!isReady(ctx)) {
                    success = false
                    errorMsg = "কিছু ফাইল অসম্পূর্ণ"
                }
            } catch (e: Exception) {
                success = false
                errorMsg = e.message ?: "ডাউনলোড ব্যর্থ"
                // clean partial files on failure
                try { dir.deleteRecursively() } catch (_: Exception) {}
            }

            downloading.set(false)

            if (success) {
                prefs.edit()
                    .putBoolean(PREF_READY, true)
                    .putLong(PREF_SIZE, totalBytes)
                    .apply()
            }

            main.post {
                if (success) {
                    listener?.onProgress(Status(true, false, 100, "মডেল প্রস্তুত!", totalBytes / (1024f * 1024f)))
                    listener?.onFinished(true, "ডাউনলোড সম্পন্ন (≈ ${"%.0f".format(totalBytes / (1024f * 1024f))} MB)")
                } else {
                    listener?.onFinished(false, errorMsg.ifEmpty { "ডাউনলোড ব্যর্থ" })
                }
            }
        }
    }
}
