package com.banglakeys.keyboard

import android.content.Context
import android.graphics.*
import android.view.View

/** All keyboard icons are drawn here (rounded, consistent line style, no emoji/font glyphs). */
object Icons {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    /** Draws icon [kind] centered in a w x h box. [sizeDp] = icon size. */
    fun draw(cv: Canvas, kind: String, color: Int, w: Int, h: Int, u: Float, sizeDp: Float = 24f) {
        cv.save()
        cv.translate(w / 2f, h / 2f)
        val s = sizeDp / 24f
        cv.scale(s, s)
        cv.translate(-12f * u, -12f * u)
        p.reset()
        p.isAntiAlias = true
        p.color = color
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.9f * u
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        p.typeface = Typeface.DEFAULT_BOLD

        fun r(a: Float, b: Float, c: Float, d: Float) = RectF(a * u, b * u, c * u, d * u)
        fun dot(x: Float, y: Float, rad: Float) {
            p.style = Paint.Style.FILL; cv.drawCircle(x * u, y * u, rad * u, p); p.style = Paint.Style.STROKE
        }
        fun poly(close: Boolean, vararg pts: Float): Path {
            val path = Path()
            path.moveTo(pts[0] * u, pts[1] * u)
            var i = 2
            while (i < pts.size) { path.lineTo(pts[i] * u, pts[i + 1] * u); i += 2 }
            if (close) path.close()
            return path
        }

        when (kind) {
            "grid" -> {
                p.style = Paint.Style.FILL
                for (i in 0..1) for (j in 0..1) {
                    val x = 3.5f + 9.5f * i; val y = 3.5f + 9.5f * j
                    cv.drawRoundRect(r(x, y, x + 7.5f, y + 7.5f), 2.4f * u, 2.4f * u, p)
                }
            }
            "clip" -> {
                cv.drawRoundRect(r(5f, 4.5f, 19f, 21.5f), 3f * u, 3f * u, p)
                p.style = Paint.Style.FILL
                cv.drawRoundRect(r(8.8f, 2f, 15.2f, 6.8f), 2f * u, 2f * u, p)
                p.style = Paint.Style.STROKE
                cv.drawLine(8.8f * u, 12f * u, 15.2f * u, 12f * u, p)
                cv.drawLine(8.8f * u, 16f * u, 13f * u, 16f * u, p)
            }
            "emoji" -> {
                cv.drawCircle(12f * u, 12f * u, 9.2f * u, p)
                dot(8.9f, 10f, 1.3f); dot(15.1f, 10f, 1.3f)
                cv.drawArc(r(7.4f, 7.2f, 16.6f, 17.2f), 25f, 130f, false, p)
            }
            "sticker" -> {
                val path = Path()
                path.moveTo(7f * u, 3f * u); path.lineTo(17f * u, 3f * u)
                path.quadTo(21f * u, 3f * u, 21f * u, 7f * u); path.lineTo(21f * u, 13f * u)
                path.lineTo(13f * u, 21f * u); path.lineTo(7f * u, 21f * u)
                path.quadTo(3f * u, 21f * u, 3f * u, 17f * u); path.lineTo(3f * u, 7f * u)
                path.quadTo(3f * u, 3f * u, 7f * u, 3f * u)
                cv.drawPath(path, p)
                cv.drawPath(Path().also { it.moveTo(21f * u, 13f * u); it.lineTo(17f * u, 13f * u); it.quadTo(13f * u, 13f * u, 13f * u, 17f * u); it.lineTo(13f * u, 21f * u) }, p)
                dot(9f, 9.5f, 1.2f); dot(14f, 9.5f, 1.2f)
                cv.drawArc(r(7f, 8f, 16f, 15f), 25f, 120f, false, p)
            }
            "num" -> {
                p.strokeWidth = 1.7f * u
                cv.drawRoundRect(r(2.5f, 5f, 21.5f, 19f), 4.5f * u, 4.5f * u, p)
                p.style = Paint.Style.FILL
                p.textAlign = Paint.Align.CENTER
                p.textSize = 9f * u
                cv.drawText("123", 12f * u, 15.2f * u, p)
            }
            "lang" -> {
                p.style = Paint.Style.FILL
                p.textAlign = Paint.Align.CENTER
                p.textSize = 15f * u
                cv.drawText("অ", 8f * u, 14f * u, p)
                p.textSize = 12f * u
                cv.drawText("A", 17f * u, 21f * u, p)
            }
            "gear" -> {
                p.strokeWidth = 2.6f * u
                for (i in 0 until 8) {
                    val a = Math.toRadians(i * 45.0)
                    val c1 = Math.cos(a).toFloat(); val s1 = Math.sin(a).toFloat()
                    cv.drawLine((12f + 8f * c1) * u, (12f + 8f * s1) * u, (12f + 9.9f * c1) * u, (12f + 9.9f * s1) * u, p)
                }
                p.strokeWidth = 2f * u
                cv.drawCircle(12f * u, 12f * u, 6.4f * u, p)
                cv.drawCircle(12f * u, 12f * u, 2.4f * u, p)
            }
            "mic" -> {
                p.style = Paint.Style.FILL
                cv.drawRoundRect(r(8.6f, 2.5f, 15.4f, 14.5f), 3.4f * u, 3.4f * u, p)
                p.style = Paint.Style.STROKE
                cv.drawArc(r(5.3f, 5.8f, 18.7f, 19.2f), 15f, 150f, false, p)
                cv.drawLine(12f * u, 19.2f * u, 12f * u, 22f * u, p)
            }
            "back" -> {
                val path = Path()
                path.moveTo(9.6f * u, 5f * u); path.lineTo(18f * u, 5f * u)
                path.quadTo(21f * u, 5f * u, 21f * u, 8f * u); path.lineTo(21f * u, 16f * u)
                path.quadTo(21f * u, 19f * u, 18f * u, 19f * u); path.lineTo(9.6f * u, 19f * u)
                path.lineTo(3.3f * u, 12f * u); path.close()
                cv.drawPath(path, p)
                cv.drawLine(12.4f * u, 9.4f * u, 17.2f * u, 14.6f * u, p)
                cv.drawLine(17.2f * u, 9.4f * u, 12.4f * u, 14.6f * u, p)
            }
            "shift" -> cv.drawPath(poly(true, 12f, 3.8f, 4.2f, 12.6f, 8.8f, 12.6f, 8.8f, 19.5f, 15.2f, 19.5f, 15.2f, 12.6f, 19.8f, 12.6f), p)
            "shiftOn" -> {
                p.style = Paint.Style.FILL_AND_STROKE
                cv.drawPath(poly(true, 12f, 3.8f, 4.2f, 12.6f, 8.8f, 12.6f, 8.8f, 19.5f, 15.2f, 19.5f, 15.2f, 12.6f, 19.8f, 12.6f), p)
            }
            "caps" -> {
                p.style = Paint.Style.FILL_AND_STROKE
                cv.drawPath(poly(true, 12f, 2.8f, 4.2f, 11.4f, 8.8f, 11.4f, 8.8f, 16.5f, 15.2f, 16.5f, 15.2f, 11.4f, 19.8f, 11.4f), p)
                p.style = Paint.Style.STROKE
                cv.drawLine(8.8f * u, 20.6f * u, 15.2f * u, 20.6f * u, p)
            }
            "enter" -> {
                val path = Path()
                path.moveTo(20f * u, 5f * u); path.lineTo(20f * u, 11f * u)
                path.quadTo(20f * u, 14f * u, 17f * u, 14f * u); path.lineTo(5f * u, 14f * u)
                cv.drawPath(path, p)
                cv.drawPath(poly(false, 9.2f, 9.8f, 5f, 14f, 9.2f, 18.2f), p)
            }
            "kbd" -> {
                cv.drawRoundRect(r(2.5f, 5.5f, 21.5f, 18.5f), 3.6f * u, 3.6f * u, p)
                for (x in listOf(6.6f, 10.2f, 13.8f, 17.4f)) dot(x, 9.6f, 1.05f)
                dot(6.6f, 13.2f, 1.05f); dot(17.4f, 13.2f, 1.05f)
                cv.drawLine(9.6f * u, 14.6f * u, 14.4f * u, 14.6f * u, p)
            }
            "palette" -> {
                cv.drawArc(r(2.8f, 2.8f, 21.2f, 21.2f), 40f, 320f, false, p)
                cv.drawPath(Path().also {
                    it.moveTo(18.6f * u, 17.2f * u); it.quadTo(15.4f * u, 17.2f * u, 15.4f * u, 19.6f * u)
                    it.quadTo(15.4f * u, 21.2f * u, 17f * u, 20.8f * u)
                }, p)
                dot(7.6f, 11.8f, 1.35f); dot(10.8f, 7.4f, 1.35f); dot(15.6f, 8f, 1.35f); dot(17.6f, 12.4f, 1.35f)
            }
            "check" -> {
                p.strokeWidth = 2.5f * u
                cv.drawPath(poly(false, 5f, 12.8f, 9.8f, 17.4f, 19f, 7f), p)
            }
            "space" -> {
                cv.drawPath(poly(false, 4.5f, 9f, 4.5f, 15f, 19.5f, 15f, 19.5f, 9f), p)
                cv.drawLine(8f * u, 19.2f * u, 16f * u, 19.2f * u, p)
            }
            "globe" -> {
                cv.drawCircle(12f * u, 12f * u, 9.2f * u, p)
                cv.drawOval(r(8f, 2.8f, 16f, 21.2f), p)
                cv.drawLine(2.8f * u, 12f * u, 21.2f * u, 12f * u, p)
                cv.drawLine(4.4f * u, 7.4f * u, 19.6f * u, 7.4f * u, p)
                cv.drawLine(4.4f * u, 16.6f * u, 19.6f * u, 16.6f * u, p)
            }
        }
        cv.restore()
    }
}

/** Standalone icon (top bar buttons). */
class IconView(c: Context, var kind: String, var color: Int) : View(c) {
    override fun onDraw(cv: Canvas) {
        Icons.draw(cv, kind, color, width, height, resources.displayMetrics.density)
    }
}

/** A key that can draw one of the icons above (kind == null -> normal text key). */
class IconKey(c: Context) : HintTextView(c) {
    var kind: String? = null
    var iconDy = 0f   // px: nudge the icon down (+) / up (-)
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val k = kind ?: return
        canvas.save()
        canvas.translate(0f, iconDy)
        Icons.draw(canvas, k, currentTextColor, width, height, resources.displayMetrics.density, 22f)
        canvas.restore()
    }
}
