package com.banglakeys.keyboard

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.*

class SettingsActivity : Activity() {
    private lateinit var p: SharedPreferences
    private lateinit var content: FrameLayout
    private lateinit var nav: LinearLayout
    private var tab = 0
    private var inSub = false
    private var chip = 0
    private val checks = ArrayList<Pair<String, View>>()

    private val BG = 0xFF1F2025.toInt()
    private val NAVBG = 0xFF35363C.toInt()
    private val CARD = 0xFF37383D.toInt()
    private val TXT = 0xFFE3E3E8.toInt()
    private val DIM = 0xFF9A9BA3.toInt()
    private val BLUE = 0xFF5280F0.toInt()
    private val HEAD = 0xFF5B84F5.toInt()
    private val CHIP = 0xFF46474D.toInt()
    private val M = -1
    private val W = -2

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun bg(c: Int, r: Int): GradientDrawable {
        val g = GradientDrawable(); g.setColor(c); g.cornerRadius = dp(r).toFloat(); return g
    }
    private fun tv(t: String, size: Float, color: Int = TXT, bold: Boolean = false): TextView {
        val v = TextView(this)
        v.text = t; v.textSize = size; v.setTextColor(color)
        if (bold) v.setTypeface(null, Typeface.BOLD)
        return v
    }

    // ---------- app (settings) language: only changes this screen, not the keyboard ----------
    private fun uiEn() = (p.getString("uilang", "bn") ?: "bn") == "en"

    private val EN = linkedMapOf(
        "ক্লিপবোর্ড হিস্ট্রি মুছুন" to "Clear clipboard history",
        "ক্লিপবোর্ড হিস্ট্রি চালু" to "Clipboard history on",
        "ক্লিপবোর্ড হিস্ট্রি" to "Clipboard history",
        "ফ্ল্যাট কি (ব্যাকগ্রাউন্ড ছাড়া)" to "Flat keys (no background)",
        "কি-এর উপরে সংখ্যা/চিহ্ন হিন্ট" to "Number/symbol hints on keys",
        "এন্টার কি রঙিন (অ্যাকসেন্ট)" to "Colored Enter key (accent)",
        "এন্টার কি রঙিন" to "Colored Enter key",
        "সাজেশন বার চালু" to "Suggestion bar on",
        "সাজেশন বার দেখান" to "Show suggestion bar",
        "কি-হাইট (dp)" to "Key height (dp)",
        "কি গ্যাপ (dp)" to "Key gap (dp)",
        "ফন্ট সাইজ (%)" to "Font size (%)",
        "ইংরেজি অটো-কারেক্ট" to "English auto-correct",
        "Import শীঘ্রই আসছে" to "Import coming soon",
        "ব্যাকগ্রাউন্ড #RRGGBB" to "Background #RRGGBB",
        "কি রঙ #RRGGBB" to "Key color #RRGGBB",
        "অ্যাকসেন্ট #RRGGBB" to "Accent #RRGGBB",
        "রঙের কোড ঠিক নেই (যেমন #1A1A20)" to "Invalid color code (e.g. #1A1A20)",
        "কি চাপলে ভাইব্রেশন" to "Vibrate on key press",
        "ফ্ল্যাট কি" to "Flat keys",
        "কি হিন্ট (সংখ্যা/চিহ্ন)" to "Key hints (numbers/symbols)",
        "কাস্টম ফন্ট ইনস্টল সুবিধা এখনো নেই।" to "Custom font install is not available yet.",
        "অ্যাপের ভাষা (শুধু এই সেটিংস অ্যাপের লেখা বদলাবে, কিবোর্ড নয়)" to "App language (changes only the text in this settings app, not the keyboard)",
        "বাংলা লেআউট" to "Bangla layout",
        "ক্লাসিক (গ্রিড)" to "Classic (grid)",
        "ফোনেটিক (অভ্র/প্রবাত স্টাইল)" to "Phonetic (Avro/Probhat style)",
        "শেখা (রিসেন্ট) শব্দ:" to "Learned (recent) words:",
        "বিল্ট-ইন ডিকশনারি:" to "Built-in dictionary:",
        "assets/bn_words.txt ও en_words.txt ফাইলে শব্দ যোগ করা যায়।" to "you can add words in assets/bn_words.txt and en_words.txt.",
        "শেখা শব্দ মুছুন" to "Clear learned words",
        "সংরক্ষিত ক্লিপ:" to "Saved clips:",
        "মুছে ফেলা হয়েছে" to "Cleared",
        "স্বরবর্ণ:" to "Vowels:",
        "ব্যঞ্জন পরপর লিখলে হসন্ত যুক্ত হয়" to "consecutive consonants join with hasanta",
        "ব্যঞ্জন:" to "Consonants:",
        "যুক্তাক্ষর:" to "Conjuncts:",
        "উদাহরণ:" to "Example:",
        "সব সেটিংস রিসেট করুন" to "Reset all settings",
        "রিসেট হয়েছে" to "Reset done",
        "শীঘ্রই আসছে" to "Coming soon",
        "এখনো তৈরি হয়নি" to "Not built yet",
        "কিবোর্ড চালু করুন" to "Enable keyboard",
        "সিস্টেম সেটিংসে অন করুন" to "Turn on in system settings",
        "এই কিবোর্ড বেছে নিন" to "Select this keyboard",
        "ইনপুট মেথড বদলান" to "Change input method",
        "টেস্ট করুন" to "Test",
        "এখানে টাইপ করে দেখুন" to "Type here to try"
    )
    private val ENS by lazy { EN.entries.sortedByDescending { it.key.length } }

    private fun T(s: String): String {
        if (!uiEn()) return s
        var r = s
        for (e in ENS) if (r.contains(e.key)) r = r.replace(e.key, e.value)
        return r
    }

    private fun toast(s: String) = Toast.makeText(this, T(s), Toast.LENGTH_SHORT).show()

    private fun lp(w: Int, h: Int, l: Int = 0, t: Int = 0, r: Int = 0, b: Int = 0): LinearLayout.LayoutParams {
        val x = LinearLayout.LayoutParams(w, h); x.setMargins(dp(l), dp(t), dp(r), dp(b)); return x
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        p = getSharedPreferences("kb", MODE_PRIVATE)
        window.statusBarColor = BG
        window.navigationBarColor = NAVBG
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(BG)
        content = FrameLayout(this)
        root.addView(content, LinearLayout.LayoutParams(M, 0, 1f))
        nav = LinearLayout(this)
        nav.setBackgroundColor(NAVBG)
        nav.setPadding(0, dp(10), 0, dp(10))
        root.addView(nav, LinearLayout.LayoutParams(M, W))
        setContentView(root)
        show(0)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { if (inSub) show(tab) else super.onBackPressed() }

    // ---------- navigation ----------
    private fun show(t: Int) {
        tab = t; inSub = false
        content.removeAllViews()
        checks.clear()
        val pg = when (t) { 0 -> homePage(); 1 -> themesPage(); else -> settingsPage() }
        content.addView(scroll(pg))
        nav.removeAllViews()
        val icons = listOf("kbd", "palette", "gear")
        for (i in 0..2) {
            val item = LinearLayout(this)
            item.gravity = Gravity.CENTER
            val ic = IconView(this, icons[i], if (i == t) Color.WHITE else DIM)
            if (i == t) ic.background = bg(BLUE, 24)
            item.addView(ic, LinearLayout.LayoutParams(dp(84), dp(40)))
            item.setOnClickListener { show(i) }
            nav.addView(item, LinearLayout.LayoutParams(0, W, 1f))
        }
    }

    private fun scroll(v: View): ScrollView { val s = ScrollView(this); s.addView(v); return s }

    private fun page(): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.VERTICAL
        l.setPadding(dp(14), dp(24), dp(14), dp(24))
        return l
    }

    private fun openSub(title: String, f: (LinearLayout) -> Unit) {
        inSub = true
        content.removeAllViews()
        val pg = page()
        val back = tv("←  ${T(title)}", 20f, TXT, true)
        back.setPadding(dp(8), dp(8), dp(8), dp(20))
        back.setOnClickListener { show(tab) }
        pg.addView(back)
        f(pg)
        content.addView(scroll(pg))
    }

    // ---------- reusable widgets ----------
    private fun header(c: LinearLayout, t: String) {
        val h = tv(T(t), 16f, HEAD, true)
        h.setPadding(dp(10), dp(28), 0, dp(14))
        c.addView(h)
    }

    private fun item(c: LinearLayout, icon: String, iconBg: Int, title: String, desc: String? = null, f: () -> Unit) {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(dp(20), dp(18), dp(16), dp(18))
        r.background = bg(CARD, 18)
        val parts = icon.split("|")
        val ic = TileIcon(this, parts[0], iconBg, parts.getOrNull(1))
        r.addView(ic, lp(dp(48), dp(48)))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.addView(tv(T(title), 18f))
        if (desc != null) col.addView(tv(T(desc), 13f, DIM))
        r.addView(col, lp(0, W, 20, 0, 0, 0).also { it.weight = 1f })
        r.setOnClickListener { f() }
        c.addView(r, lp(M, W, 0, 0, 0, 4))
    }

    private fun plain(c: LinearLayout, title: String, f: () -> Unit) {
        val t = tv(T(title), 18f)
        t.setPadding(dp(24), dp(28), dp(24), dp(28))
        t.background = bg(CARD, 18)
        t.setOnClickListener { f() }
        c.addView(t, lp(M, W, 0, 0, 0, 6))
    }

    private fun sw(c: LinearLayout, key: String, text: String, def: Boolean, after: (() -> Unit)? = null) {
        val s = Switch(this)
        s.text = T(text); s.setTextColor(TXT); s.textSize = 16f
        s.isChecked = p.getBoolean(key, def)
        s.setPadding(dp(18), dp(16), dp(18), dp(16))
        s.background = bg(CARD, 16)
        s.setOnCheckedChangeListener { _, ch -> p.edit().putBoolean(key, ch).apply(); after?.invoke() }
        c.addView(s, lp(M, W, 0, 0, 0, 4))
    }

    private fun radios(c: LinearLayout, key: String, def: String, opts: List<Pair<String, String>>, after: (() -> Unit)? = null) {
        val g = RadioGroup(this)
        g.setPadding(dp(14), dp(8), dp(14), dp(8))
        g.background = bg(CARD, 16)
        for (o in opts) {
            val r = RadioButton(this)
            r.text = T(o.second); r.setTextColor(TXT); r.textSize = 16f
            r.id = View.generateViewId(); r.tag = o.first
            r.isChecked = (p.getString(key, def) ?: def) == o.first
            g.addView(r)
        }
        g.setOnCheckedChangeListener { grp, id ->
            val v = grp.findViewById<View>(id)
            if (v != null) { p.edit().putString(key, v.tag as String).apply(); after?.invoke() }
        }
        c.addView(g, lp(M, W, 0, 0, 0, 4))
    }

    private fun seek(c: LinearLayout, key: String, min: Int, max: Int, def: Int, title: String) {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(18), dp(16), dp(18), dp(16))
        box.background = bg(CARD, 16)
        val cur = p.getInt(key, def)
        val ttl = T(title)
        val lab = tv("$ttl: $cur", 16f)
        val sb = SeekBar(this)
        sb.max = max - min
        sb.progress = cur - min
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, v: Int, u: Boolean) {
                lab.text = "$ttl: ${v + min}"
                p.edit().putInt(key, v + min).apply()
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        box.addView(lab); box.addView(sb)
        c.addView(box, lp(M, W, 0, 0, 0, 4))
    }

    private fun note(c: LinearLayout, t: String) {
        val v = tv(T(t), 15f, DIM)
        v.setPadding(dp(14), dp(10), dp(14), dp(10))
        c.addView(v)
    }

    private fun btn(c: LinearLayout, t: String, f: () -> Unit) {
        val b = Button(this)
        b.text = T(t); b.setOnClickListener { f() }
        c.addView(b)
    }

    // ---------- default keyboard setup ----------
    private fun isEnabled(): Boolean {
        val im = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        return im.enabledInputMethodList.any { it.packageName == packageName }
    }

    private fun isDefault(): Boolean {
        val d = Settings.Secure.getString(contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD) ?: return false
        return d.startsWith("$packageName/")
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && ::content.isInitialized && !inSub && tab == 0) show(0)
    }

    // ---------- Home (💡) ----------
    private fun homePage(): LinearLayout {
        val pg = page()
        val th = Themes.get(p.getString("theme", "dark") ?: "dark", p)
        val flat = p.getBoolean("flat", false)
        val hints = p.getBoolean("hints", true)

        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(dp(14), dp(14), dp(14), dp(14))
        card.background = bg(CARD, 28)

        val kb = LinearLayout(this)
        kb.orientation = LinearLayout.VERTICAL
        kb.setPadding(dp(6), dp(6), dp(6), dp(10))
        val g = th.grad
        if (g != null) {
            val gd = GradientDrawable(GradientDrawable.Orientation.TL_BR, g)
            gd.cornerRadius = dp(24).toFloat(); kb.background = gd
        } else kb.background = bg(th.bg, 24)

        val tb = LinearLayout(this)
        tb.gravity = Gravity.CENTER_VERTICAL
        for (k in listOf("lang", "emoji", "sticker", "num", "clip", "grid")) {
            tb.addView(IconView(this, k, th.text), LinearLayout.LayoutParams(0, dp(44), 1f))
        }
        val mic = IconView(this, "mic", th.text)
        mic.background = GradientDrawable().also { it.shape = GradientDrawable.OVAL; it.setColor(th.keyAlt) }
        tb.addView(mic, LinearLayout.LayoutParams(dp(44), dp(44)))
        kb.addView(tb)

        fun prow(letters: String, hs: String, pad: Int, pre: String? = null, post: String? = null) {
            val r = LinearLayout(this)
            r.setPadding(dp(pad), 0, dp(pad), 0)
            fun side(s: String) {
                val v = IconView(this, if (s == "⇧") "shift" else "back", th.text)
                r.addView(v, LinearLayout.LayoutParams(0, dp(42), 1.4f))
            }
            if (pre != null) side(pre)
            for ((i, ch) in letters.withIndex()) {
                val t = HintTextView(this)
                t.text = ch.toString().uppercase(); t.textSize = 20f; t.setTextColor(th.text)
                t.gravity = Gravity.CENTER
                if (!flat) t.background = bg(th.key, 8)
                if (hints && i < hs.length) { t.hintText = hs[i].toString(); t.hintColor = th.dim; t.hintSize = dp(10).toFloat() }
                r.addView(t, lp(0, dp(42), 1, 2, 1, 2).also { it.weight = 1f })
            }
            if (post != null) side(post)
            kb.addView(r)
        }
        prow("qwertyuiop", "1234567890", 0)
        prow("asdfghjkl", "@#\$%&-+()", 14)
        prow("zxcvbnm", "*\"':;!?", 0, "⇧", "⌫")

        val bot = LinearLayout(this)
        bot.gravity = Gravity.CENTER_VERTICAL
        fun pill(s: String, w: Float, c: Int, tc: Int) {
            val t: View = if (s == "⏎") IconView(this, "enter", tc) else tv(s, 15f, tc).also { it.gravity = Gravity.CENTER }
            if (c != 0) t.background = bg(c, 22)
            bot.addView(t, lp(0, dp(42), 2, 4, 2, 0).also { it.weight = w })
        }
        pill("?123", 1.4f, th.keyAlt, th.text)
        pill(",", 1f, 0, th.text)
        pill("", 4f, th.keyAlt, th.text)
        pill(".", 1f, 0, th.text)
        val ea = p.getBoolean("enteraccent", true)
        pill("⏎", 1.4f, if (ea) th.accent else th.keyAlt, if (ea) th.onAccent else th.text)
        kb.addView(bot)
        card.addView(kb)

        val chips = LinearLayout(this)
        chips.setPadding(0, dp(18), 0, dp(4))
        val labels = listOf("A", "123", "😊", "@", "⧉")
        for (i in labels.indices) {
            val t = tv(labels[i], 18f, if (i == chip) Color.WHITE else TXT, true)
            t.gravity = Gravity.CENTER
            t.background = bg(if (i == chip) BLUE else CHIP, 18)
            t.setOnClickListener { chip = i; show(0) }
            chips.addView(t, lp(0, dp(56), 4, 0, 4, 0).also { it.weight = 1f })
        }
        card.addView(chips)
        pg.addView(card, lp(M, W, 0, 0, 0, 14))

        val opt = LinearLayout(this)
        opt.orientation = LinearLayout.VERTICAL
        val re = { show(0) }
        when (chip) {
            0 -> sw(opt, "flat", "ফ্ল্যাট কি (ব্যাকগ্রাউন্ড ছাড়া)", false, re)
            1 -> sw(opt, "hints", "কি-এর উপরে সংখ্যা/চিহ্ন হিন্ট", true, re)
            2 -> sw(opt, "sugg", "সাজেশন বার চালু", true, re)
            3 -> sw(opt, "enteraccent", "এন্টার কি রঙিন (অ্যাকসেন্ট)", true, re)
            else -> sw(opt, "clipon", "ক্লিপবোর্ড হিস্ট্রি", true, re)
        }
        pg.addView(opt, lp(M, W, 0, 0, 0, 10))

        plain(pg, "Key Gap and Font Size") {
            openSub("Key Gap and Font Size") { c ->
                seek(c, "keyh", 40, 80, 48, "কি-হাইট (dp)")
                seek(c, "gap", 1, 6, 2, "কি গ্যাপ (dp)")
                seek(c, "fscale", 80, 140, 100, "ফন্ট সাইজ (%)")
            }
        }
        plain(pg, "Suggestion Bar Style") {
            openSub("Suggestion Bar Style") { c ->
                sw(c, "sugg", "সাজেশন বার দেখান", true)
                sw(c, "autocorrect", "ইংরেজি অটো-কারেক্ট", true)
            }
        }
        return pg
    }

    // ---------- Themes (🎨) ----------
    private fun themesPage(): LinearLayout {
        val pg = page()
        pg.addView(tv("Themes", 30f, TXT, true).also { it.setPadding(dp(10), 0, 0, dp(10)) })
        val tileW = (resources.displayMetrics.widthPixels - dp(28) - dp(36)) / 3

        val mh = LinearLayout(this)
        mh.gravity = Gravity.CENTER_VERTICAL
        mh.addView(tv("My Themes", 22f).also { it.setPadding(dp(10), dp(16), 0, dp(16)) }, LinearLayout.LayoutParams(0, W, 1f))
        val imp = tv("Import", 16f, Color.WHITE)
        imp.setPadding(dp(26), dp(12), dp(26), dp(12))
        imp.background = bg(0xFF3A4472.toInt(), 22)
        imp.setOnClickListener { toast("Import শীঘ্রই আসছে") }
        mh.addView(imp)
        pg.addView(mh)

        val my = LinearLayout(this)
        val plus = FrameLayout(this)
        val pbox = FrameLayout(this)
        pbox.background = bg(0xFF18191D.toInt(), 22)
        val pl = tv("+", 30f, 0xFFB8C0FF.toInt()); pl.gravity = Gravity.CENTER
        pl.background = GradientDrawable().also { it.shape = GradientDrawable.OVAL; it.setColor(0xFF37383D.toInt()) }
        pbox.addView(pl, FrameLayout.LayoutParams(dp(56), dp(56), Gravity.CENTER))
        plus.addView(pbox, FrameLayout.LayoutParams(tileW, (tileW * 0.77f).toInt()))
        val pc = LinearLayout(this); pc.orientation = LinearLayout.VERTICAL; pc.gravity = Gravity.CENTER_HORIZONTAL
        pc.addView(plus); pc.addView(tv("Create Theme", 14f).also { it.setPadding(0, dp(8), 0, 0) })
        pc.setOnClickListener { createTheme() }
        my.addView(pc, lp(W, W, 6, 0, 6, 0))
        if (p.contains("c_bg")) my.addView(tile("custom", "My Theme", tileW), lp(W, W, 6, 0, 6, 0))
        pg.addView(my)

        pg.addView(tv("Platform Themes", 22f).also { it.setPadding(dp(10), dp(28), 0, dp(14)) })
        grid(pg, listOf("light" to "Light", "dark" to "Dark", "navy" to "Navy"), tileW)
        pg.addView(tv("Exclusive", 22f).also { it.setPadding(dp(10), dp(28), 0, dp(14)) })
        grid(pg, listOf("glass" to "Glass Dark", "bangla" to "Bangla-first"), tileW)
        pg.addView(tv("Colors", 22f).also { it.setPadding(dp(10), dp(28), 0, dp(14)) })
        grid(pg, Themes.colors.indices.map { "c$it" to "" }, tileW)
        return pg
    }

    private fun grid(c: LinearLayout, items: List<Pair<String, String>>, tileW: Int) {
        for (chunk in items.chunked(3)) {
            val row = LinearLayout(this)
            for (it in chunk) row.addView(tile(it.first, it.second.ifEmpty { null }, tileW), lp(W, W, 6, 0, 6, 10))
            c.addView(row)
        }
    }

    private fun tile(id: String, label: String?, w: Int): View {
        val th = Themes.get(id, p)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER_HORIZONTAL
        val fr = FrameLayout(this)
        val box = FrameLayout(this)
        val g = th.grad
        if (g != null) {
            val gd = GradientDrawable(GradientDrawable.Orientation.TL_BR, g)
            gd.cornerRadius = dp(22).toFloat(); box.background = gd
        } else box.background = bg(th.bg, 22)
        val h = (w * 0.77f).toInt()
        val bar = View(this); bar.background = bg(th.key, 6)
        box.addView(bar, FrameLayout.LayoutParams((w * 0.5f).toInt(), (h * 0.15f).toInt(), Gravity.BOTTOM or Gravity.START).also {
            it.setMargins(dp(14), 0, 0, dp(14))
        })
        val ac = View(this); ac.background = bg(th.accent, 6)
        box.addView(ac, FrameLayout.LayoutParams((w * 0.14f).toInt(), (w * 0.14f).toInt(), Gravity.BOTTOM or Gravity.END).also {
            it.setMargins(0, 0, dp(14), dp(14))
        })
        fr.addView(box, FrameLayout.LayoutParams(w, h))
        val ck = tv("✓", 22f, Color.WHITE, true)
        ck.gravity = Gravity.CENTER
        ck.background = GradientDrawable().also { it.shape = GradientDrawable.OVAL; it.setColor(BLUE); it.setStroke(dp(2), Color.WHITE) }
        fr.addView(ck, FrameLayout.LayoutParams(dp(52), dp(52), Gravity.CENTER))
        ck.visibility = if ((p.getString("theme", "dark") ?: "dark") == id) View.VISIBLE else View.INVISIBLE
        checks.add(Pair(id, ck))
        fr.setOnClickListener {
            p.edit().putString("theme", id).apply()
            for (x in checks) x.second.visibility = if (x.first == id) View.VISIBLE else View.INVISIBLE
        }
        col.addView(fr)
        if (label != null) col.addView(tv(label, 14f).also { it.setPadding(0, dp(8), 0, 0) })
        return col
    }

    private fun createTheme() {
        val th = Themes.get(p.getString("theme", "dark") ?: "dark", p)
        val l = LinearLayout(this)
        l.orientation = LinearLayout.VERTICAL
        l.setPadding(dp(20), dp(10), dp(20), dp(0))
        fun field(h: String, c: Int): EditText {
            val e = EditText(this)
            e.hint = h; e.setText(String.format("#%06X", c and 0xFFFFFF))
            l.addView(e); return e
        }
        val a = field(T("ব্যাকগ্রাউন্ড #RRGGBB"), th.bg)
        val k = field(T("কি রঙ #RRGGBB"), th.key)
        val c = field(T("অ্যাকসেন্ট #RRGGBB"), th.accent)
        AlertDialog.Builder(this).setTitle("Create Theme").setView(l)
            .setPositiveButton("Save") { _, _ ->
                try {
                    p.edit().putInt("c_bg", Color.parseColor(a.text.toString().trim()))
                        .putInt("c_key", Color.parseColor(k.text.toString().trim()))
                        .putInt("c_acc", Color.parseColor(c.text.toString().trim()))
                        .putString("theme", "custom").apply()
                    show(1)
                } catch (e: Exception) {
                    toast("রঙের কোড ঠিক নেই (যেমন #1A1A20)")
                }
            }
            .setNegativeButton("Cancel", null).show()
    }

    // ---------- Settings (⚙) ----------
    private fun langPage() {
        openSub("Language") { c ->
            note(c, "অ্যাপের ভাষা (শুধু এই সেটিংস অ্যাপের লেখা বদলাবে, কিবোর্ড নয়)")
            radios(c, "uilang", "bn", listOf("bn" to "বাংলা", "en" to "English")) { langPage() }
        }
    }

    private fun settingsPage(): LinearLayout {
        val pg = page()
        item(pg, "palette", 0xFFFF5C7A.toInt(), "Themes") { show(1) }
        item(pg, "sliders", 0xFFFFA928.toInt(), "Preferences") {
            openSub("Preferences") { c ->
                sw(c, "vibrate", "কি চাপলে ভাইব্রেশন", true)
                sw(c, "flat", "ফ্ল্যাট কি", false)
                sw(c, "hints", "কি হিন্ট (সংখ্যা/চিহ্ন)", true)
                sw(c, "enteraccent", "এন্টার কি রঙিন", true)
            }
        }
        item(pg, "font", 0xFF9B5CF6.toInt(), "Font Manager") {
            openSub("Font Manager") { c ->
                seek(c, "fscale", 80, 140, 100, "ফন্ট সাইজ (%)")
                note(c, "কাস্টম ফন্ট ইনস্টল সুবিধা এখনো নেই।")
            }
        }

        header(pg, "Keyboard")
        item(pg, "globe", 0xFF14B8A6.toInt(), "Language", if (uiEn()) "English" else "বাংলা") { langPage() }
        item(pg, "kbd", 0xFF3B82F6.toInt(), "Keyboard Layouts") {
            openSub("Keyboard Layouts") { c ->
                note(c, "বাংলা লেআউট")
                radios(c, "bnlayout", "classic", listOf("classic" to "ক্লাসিক (গ্রিড)", "phonetic" to "ফোনেটিক (অভ্র/প্রবাত স্টাইল)"))
            }
        }
        item(pg, "suggest", 0xFF6366F1.toInt(), "Suggestion Bar & Text Correction") {
            openSub("Suggestion Bar & Text Correction") { c ->
                sw(c, "sugg", "সাজেশন বার দেখান", true)
                sw(c, "autocorrect", "ইংরেজি অটো-কারেক্ট", true)
            }
        }
        item(pg, "book", 0xFFF472B6.toInt(), "Learning & Dictionaries") {
            openSub("Learning & Dictionaries") { c ->
                val n = (p.getString("recent", "") ?: "").split("\u0001").count { it.isNotEmpty() }
                note(c, "শেখা (রিসেন্ট) শব্দ: $n\nবিল্ট-ইন ডিকশনারি: assets/bn_words.txt ও en_words.txt ফাইলে শব্দ যোগ করা যায়।")
                btn(c, "শেখা শব্দ মুছুন") { p.edit().remove("recent").apply(); toast("মুছে ফেলা হয়েছে"); show(tab) }
            }
        }
        item(pg, "clip", 0xFFFB7C3A.toInt(), "Clipboard") {
            openSub("Clipboard") { c ->
                sw(c, "clipon", "ক্লিপবোর্ড হিস্ট্রি চালু", true)
                val n = (p.getString("clips", "") ?: "").split("\u0001").count { it.isNotEmpty() }
                note(c, "সংরক্ষিত ক্লিপ: $n")
                btn(c, "ক্লিপবোর্ড হিস্ট্রি মুছুন") { p.edit().remove("clips").apply(); toast("মুছে ফেলা হয়েছে"); show(tab) }
            }
        }

        // ---------- Offline Voice Model (int8 Bengali) ----------
        header(pg, "Voice Typing")
        item(pg, "mic", 0xFF10B981.toInt(), "অফলাইন বাংলা মডেল", offlineModelSubtitle()) {
            openSub("অফলাইন বাংলা মডেল") { c -> voiceModelPage(c) }
        }

        item(pg, "keymap", 0xFF7C3AED.toInt(), "Borno Phonetic Keymap") {
            openSub("Borno Phonetic Keymap") { c ->
                val t = tv(
                    T("স্বরবর্ণ: o=অ a=আ i=ই I/ee=ঈ u=উ U/oo=ঊ rri=ঋ e=এ oi=ঐ O=ও ou=ঔ\n" +
                    "ব্যঞ্জন: k=ক kh=খ g=গ gh=ঘ Ng=ঙ c=চ ch=ছ j=জ jh=ঝ NG=ঞ\n" +
                    "T=ট Th=ঠ D=ড Dh=ঢ N=ণ t=ত th=থ d=দ dh=ধ n=ন\n" +
                    "p=প f/ph=ফ b=ব v/bh=ভ m=ম z=য r=র l=ল sh=শ Sh=ষ s=স h=হ\n" +
                    "R=ড় Rh=ঢ় y=য় t``=ৎ ng=ং :=ঃ ^=ঁ\n" +
                    "যুক্তাক্ষর: kk=ক্ক, kkh=ক্ষ (ব্যঞ্জন পরপর লিখলে হসন্ত যুক্ত হয়)\n" +
                    "উদাহরণ: ami=আমি, bangla=বাংলা, bhalO=ভালো, valo=ভালো"), 16f
                )
                t.setLineSpacing(0f, 1.3f)
                t.setPadding(dp(16), dp(16), dp(16), dp(16)); t.background = bg(CARD, 16)
                c.addView(t)
            }
        }
        item(pg, "more", 0xFF64748B.toInt(), "Advanced") {
            openSub("Advanced") { c ->
                btn(c, "সব সেটিংস রিসেট করুন") { p.edit().clear().apply(); toast("রিসেট হয়েছে"); show(tab) }
            }
        }

        header(pg, "Gestures")
        item(pg, "swap", 0xFF0EA5E9.toInt(), "Smart Gestures", "শীঘ্রই আসছে") { toast("এখনো তৈরি হয়নি") }
        item(pg, "swirl", 0xFFD946EF.toInt(), "Gesture Typing", "শীঘ্রই আসছে") { toast("এখনো তৈরি হয়নি") }

        header(pg, "App")
        item(pg, "power|1", 0xFF22C55E.toInt(), "কিবোর্ড চালু করুন", "সিস্টেম সেটিংসে অন করুন") { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }
        item(pg, "pointer|2", 0xFF10B981.toInt(), "এই কিবোর্ড বেছে নিন", "ইনপুট মেথড বদলান") {
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        }
        item(pg, "pencil", 0xFF475569.toInt(), "টেস্ট করুন") {
            openSub("টেস্ট করুন") { c ->
                val et = EditText(this)
                et.hint = T("এখানে টাইপ করে দেখুন"); et.setTextColor(TXT); et.setHintTextColor(DIM)
                c.addView(et)
            }
        }
        return pg
    }

    // ==================== Offline Voice Model UI ====================

    private fun offlineModelSubtitle(): String {
        val st = OfflineModelManager.currentStatus(this, p)
        return when {
            st.ready -> "প্রস্তুত • ${"%.0f".format(st.sizeMb)} MB"
            st.downloading -> "ডাউনলোড চলছে…"
            else -> "ডাউনলোড করুন (≈ ২৯ MB)"
        }
    }

    private fun voiceModelPage(c: LinearLayout) {
        // status card
        val statusTv = tv("", 16f)
        statusTv.setPadding(dp(16), dp(14), dp(16), dp(14))
        statusTv.background = bg(CARD, 14)
        c.addView(statusTv, lp(M, W, 0, 0, 0, 12))

        // progress bar
        val progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        progress.max = 100
        progress.progress = 0
        progress.visibility = View.GONE
        c.addView(progress, lp(M, W, 0, 0, 0, 12))

        // prefer offline switch
        sw(c, "prefer_offline", "অফলাইন মডেল ব্যবহার করো (যখন প্রস্তুত)", false)

        note(c, "int8 কোয়ান্টাইজড বাংলা স্ট্রিমিং মডেল (≈ ২৯ MB)।\nএকবার ডাউনলোড করলে ইন্টারনেট ছাড়াই কাজ করবে।\nমডেল: vosk-small-streaming-bn-int8")

        val downloadBtn = Button(this)
        downloadBtn.setTextColor(Color.WHITE)
        downloadBtn.background = bg(0xFF10B981.toInt(), 14)
        downloadBtn.setPadding(dp(20), dp(14), dp(20), dp(14))
        c.addView(downloadBtn, lp(M, W, 0, 12, 0, 8))

        val deleteBtn = Button(this)
        deleteBtn.text = T("মডেল মুছে ফেলুন")
        deleteBtn.setTextColor(Color.WHITE)
        deleteBtn.background = bg(0xFFEF4444.toInt(), 14)
        deleteBtn.setPadding(dp(20), dp(14), dp(20), dp(14))
        c.addView(deleteBtn, lp(M, W, 0, 0, 0, 8))

        fun refresh() {
            val st = OfflineModelManager.currentStatus(this, p)
            statusTv.text = st.message
            if (st.downloading) {
                progress.visibility = View.VISIBLE
                progress.progress = st.progress
                downloadBtn.isEnabled = false
                downloadBtn.text = T("ডাউনলোড চলছে… ${st.progress}%")
                deleteBtn.isEnabled = false
            } else if (st.ready) {
                progress.visibility = View.GONE
                downloadBtn.isEnabled = false
                downloadBtn.text = T("✓ মডেল প্রস্তুত")
                deleteBtn.isEnabled = true
            } else {
                progress.visibility = View.GONE
                downloadBtn.isEnabled = true
                downloadBtn.text = T("ডাউনলোড করুন (≈ ২৯ MB)")
                deleteBtn.isEnabled = false
            }
        }

        refresh()

        downloadBtn.setOnClickListener {
            downloadBtn.isEnabled = false
            progress.visibility = View.VISIBLE
            progress.progress = 0
            OfflineModelManager.download(this, p, object : OfflineModelManager.Listener {
                override fun onProgress(status: OfflineModelManager.Status) {
                    statusTv.text = status.message
                    progress.progress = status.progress
                    downloadBtn.text = T("ডাউনলোড চলছে… ${status.progress}%")
                }
                override fun onFinished(success: Boolean, message: String) {
                    toast(message)
                    refresh()
                }
            })
        }

        deleteBtn.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle(T("মডেল মুছে ফেলবেন?"))
                .setMessage(T("ডাউনলোড করা অফলাইন মডেল মুছে যাবে। পরে আবার ডাউনলোড করতে পারবেন।"))
                .setPositiveButton(T("মুছে ফেলুন")) { _, _ ->
                    OfflineModelManager.deleteModel(this, p)
                    toast("মডেল মুছে ফেলা হয়েছে")
                    refresh()
                }
                .setNegativeButton(T("বাতিল"), null)
                .show()
        }
    }
}
