package com.banglakeys.keyboard

import android.content.Context
import android.graphics.*
import android.view.View

/** Modern settings tile: soft gradient squircle + glossy edge + crisp white line glyph (all drawn in code). */
class TileIcon(c: Context, private val kind: String, private val base: Int, private val badge: String? = null) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val d = c.resources.displayMetrics.density

    private fun mix(a: Int, b: Int, t: Float): Int {
        val r = (Color.red(a) + (Color.red(b) - Color.red(a)) * t).toInt()
        val g = (Color.green(a) + (Color.green(b) - Color.green(a)) * t).toInt()
        val bl = (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t).toInt()
        return Color.rgb(r, g, bl)
    }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val rad = 15f * d
        val box = RectF(0f, 0f, w, h)
        // gradient body
        p.reset(); p.isAntiAlias = true
        p.shader = LinearGradient(0f, 0f, w, h, mix(base, Color.WHITE, 0.28f), mix(base, Color.BLACK, 0.22f), Shader.TileMode.CLAMP)
        cv.drawRoundRect(box, rad, rad, p)
        // soft top gloss
        p.shader = LinearGradient(0f, 0f, 0f, h * 0.55f, Color.argb(70, 255, 255, 255), Color.argb(0, 255, 255, 255), Shader.TileMode.CLAMP)
        cv.drawRoundRect(box, rad, rad, p)
        // thin glass edge
        p.shader = null; p.style = Paint.Style.STROKE; p.strokeWidth = 1f * d; p.color = Color.argb(60, 255, 255, 255)
        cv.drawRoundRect(RectF(0.5f * d, 0.5f * d, w - 0.5f * d, h - 0.5f * d), rad, rad, p)

        val u = 26f * d / 24f
        val ox = (w - 24f * u) / 2f; val oy = (h - 24f * u) / 2f
        // glyph shadow then glyph
        for (pass in 0..1) {
            cv.save()
            cv.translate(ox, oy + if (pass == 0) 1.2f * d else 0f)
            cv.scale(u, u)
            glyph(cv, if (pass == 0) Color.argb(55, 0, 0, 0) else Color.WHITE)
            cv.restore()
        }
        if (badge != null) {
            val cx = w - 9f * d; val cy = h - 9f * d
            p.reset(); p.isAntiAlias = true
            p.color = Color.WHITE; cv.drawCircle(cx, cy, 8f * d, p)
            p.color = mix(base, Color.BLACK, 0.25f); p.textAlign = Paint.Align.CENTER
            p.textSize = 11f * d; p.typeface = Typeface.DEFAULT_BOLD
            cv.drawText(badge, cx, cy + 4f * d, p)
        }
    }

    private fun glyph(cv: Canvas, col: Int) {
        p.reset(); p.isAntiAlias = true
        p.color = col; p.style = Paint.Style.STROKE; p.strokeWidth = 1.8f
        p.strokeCap = Paint.Cap.ROUND; p.strokeJoin = Paint.Join.ROUND
        fun dot(x: Float, y: Float, r: Float) { p.style = Paint.Style.FILL; cv.drawCircle(x, y, r, p); p.style = Paint.Style.STROKE }
        fun ln(a: Float, b: Float, c: Float, e: Float) = cv.drawLine(a, b, c, e, p)
        fun poly(close: Boolean, vararg v: Float) {
            val pa = Path(); pa.moveTo(v[0], v[1]); var i = 2
            while (i < v.size) { pa.lineTo(v[i], v[i + 1]); i += 2 }
            if (close) pa.close(); cv.drawPath(pa, p)
        }
        when (kind) {
            "palette" -> {
                cv.drawCircle(12f, 12f, 9f, p)
                dot(7.8f, 11f, 1.3f); dot(10.4f, 7.4f, 1.3f); dot(15f, 7.8f, 1.3f); dot(16.6f, 12.2f, 1.3f)
                cv.drawArc(RectF(10f, 13f, 16f, 20f), 200f, 160f, false, p)
            }
            "sliders" -> {
                ln(4f, 6f, 20f, 6f); ln(4f, 12f, 20f, 12f); ln(4f, 18f, 20f, 18f)
                dot(8f, 6f, 2.6f); dot(16f, 12f, 2.6f); dot(10f, 18f, 2.6f)
            }
            "font" -> {
                poly(false, 3.5f, 19f, 8.5f, 5f, 13.5f, 19f); ln(5.4f, 14.2f, 11.6f, 14.2f)
                cv.drawCircle(18f, 15.8f, 2.9f, p); ln(20.9f, 12.9f, 20.9f, 18.7f)
            }
            "globe" -> {
                cv.drawCircle(12f, 12f, 9f, p)
                cv.drawOval(RectF(8f, 3f, 16f, 21f), p)
                ln(3f, 12f, 21f, 12f); ln(4.6f, 7.4f, 19.4f, 7.4f); ln(4.6f, 16.6f, 19.4f, 16.6f)
            }
            "kbd" -> {
                cv.drawRoundRect(RectF(2.5f, 5.5f, 21.5f, 18.5f), 3.5f, 3.5f, p)
                for (i in 0..3) dot(6.8f + i * 3.5f, 9.6f, 0.95f)
                for (i in 0..2) dot(8.5f + i * 3.5f, 12.8f, 0.95f)
                ln(8f, 15.6f, 16f, 15.6f)
            }
            "keymap" -> {
                cv.drawRoundRect(RectF(3f, 3f, 21f, 21f), 5f, 5f, p)
                p.style = Paint.Style.FILL; p.textAlign = Paint.Align.CENTER; p.textSize = 12f; p.typeface = Typeface.DEFAULT_BOLD
                cv.drawText("ক", 12f, 16.4f, p)
            }
            "suggest" -> {
                cv.drawRoundRect(RectF(3f, 3.5f, 21f, 16.5f), 4.5f, 4.5f, p)
                poly(false, 8f, 16.5f, 8f, 20.5f, 12.2f, 16.5f)
                poly(false, 7.8f, 10f, 10.8f, 13f, 16.2f, 7.2f)
            }
            "book" -> {
                val l = Path(); l.moveTo(12f, 6.5f); l.cubicTo(10f, 4.6f, 6.5f, 4.3f, 3.5f, 5.4f); l.lineTo(3.5f, 18.6f); l.cubicTo(6.5f, 17.5f, 10f, 17.9f, 12f, 19.6f)
                val r = Path(); r.moveTo(12f, 6.5f); r.cubicTo(14f, 4.6f, 17.5f, 4.3f, 20.5f, 5.4f); r.lineTo(20.5f, 18.6f); r.cubicTo(17.5f, 17.5f, 14f, 17.9f, 12f, 19.6f)
                cv.drawPath(l, p); cv.drawPath(r, p); ln(12f, 6.5f, 12f, 19.6f)
            }
            "clip" -> {
                cv.drawRoundRect(RectF(5f, 4.5f, 19f, 21.5f), 3.2f, 3.2f, p)
                p.style = Paint.Style.FILL; cv.drawRoundRect(RectF(8.8f, 2f, 15.2f, 6.8f), 2f, 2f, p); p.style = Paint.Style.STROKE
                ln(8.8f, 12f, 15.2f, 12f); ln(8.8f, 16f, 13f, 16f)
            }
            "more" -> { dot(5.5f, 12f, 1.9f); dot(12f, 12f, 1.9f); dot(18.5f, 12f, 1.9f) }
            "swap" -> {
                ln(4f, 8f, 20f, 8f); poly(false, 16f, 4.2f, 20f, 8f, 16f, 11.8f)
                ln(20f, 16f, 4f, 16f); poly(false, 8f, 12.2f, 4f, 16f, 8f, 19.8f)
            }
            "swirl" -> {
                val s = Path(); s.moveTo(3.5f, 16f); s.cubicTo(5.5f, 5f, 10f, 5f, 11.5f, 12f); s.cubicTo(13f, 19f, 17.5f, 19f, 20.5f, 8f)
                cv.drawPath(s, p); dot(3.5f, 16f, 1.5f); dot(20.5f, 8f, 1.9f)
            }
            "power" -> {
                cv.drawArc(RectF(5f, 5.5f, 19f, 19.5f), -50f, 280f, false, p); ln(12f, 3.5f, 12f, 11.5f)
            }
            "pointer" -> {
                poly(true, 6f, 3.5f, 6f, 17.5f, 9.6f, 14.2f, 12.2f, 20.2f, 14.6f, 19.2f, 12.1f, 13.2f, 17f, 13.2f)
            }
            "pencil" -> {
                poly(true, 4f, 20f, 4.6f, 15.4f, 15.6f, 4.4f, 19.6f, 8.4f, 8.6f, 19.4f)
                ln(13f, 7f, 17f, 11f)
            }
        }
    }
}
